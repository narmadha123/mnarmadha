import sys
import time
import datetime
import os
from time import strftime
from datetime import datetime, timedelta
from flask import Flask, render_template, url_for, request

app = Flask(__name__)

@app.route('/')
@app.route('/home')
def home():
    return render_template("index.html")

@app.route('/result',methods=['POST', 'GET'])
def result():
    output = request.args.get("SmallParser")
    print(output)
    content=program(output)
    print(content)
    return render_template('index2.html', text=content)

def parse_time(s):
        return datetime.strptime(s, '%I:%M%p')
def time_diff(st, et):
    diff = 0
    if (len(st) > 0 and len(et) > 0):
        st = parse_time(st)
        et = parse_time(et)
        if et < st:            
            et += timedelta(days=1)
        diff = et - st
    return diff
def add_time(timeListI):  
    totalSecs = 0
    timeList = map(str, timeListI)
    for tm in timeList:        
        if tm.find(":"):
            timeParts = [int(s) for s in tm.split(':')]
            totalSecs += (timeParts[0] * 60 + timeParts[1]) * 60 + timeParts[2]
    totalSecs, sec = divmod(totalSecs, 60)
    hr, min = divmod(totalSecs, 60)
    TimeTaken = "Total:", "%d hours :%02d minutes :%02d seconds" % (hr, min, sec)
    print(TimeTaken)
    return TimeTaken

# Main program
def program(*args):
    try:
        with open(args[0], 'r') as f:
            content = [line for line in f.readlines() if line.strip()]
            s = content[0].find('Time Log')
            if s == -1:
                print("Invalid File")
                sys.exit()
            content = [x.strip() for x in content]
            content = content[1:]
            timeloglist = list()
        f.close()
    except FileNotFoundError:
        print('Input log file invalid, please try again!')
    for index, item in enumerate(content):
        flag = item.find('/', 0, 9)
        if (flag > 0):
            item = item.partition(':')[2]
        else:
            item = item
        if (item.find(',')):
            item2 = item.partition(',')[2]

            sttime2 = item2.partition('-')[0].strip()

            if len(sttime2) > 0:
                starttime2 = sttime2
            else:
                starttime2 = ''

            item2 = item2.partition('-')[2]

            if len(item2) > 0:
                item2 = item2.split()
                edtime2 = item2[0].strip()
                endtime2 = edtime2
            else:
                endtime2 = ''

            if (len(starttime2) > 0 and len(endtime2) > 0):
                timeloglist.append(time_diff(starttime2, endtime2))

        item = item.partition(',')[0]

        sttime = item.partition('-')[0].strip()

        if len(sttime) > 0:
            starttime = sttime
        else:
            starttime = ''

        item = item.partition('-')[2]

        if len(item) > 0:
            item = item.split()
            edtime = item[0].strip()
            endtime = edtime
        else:
            endtime = ''

        if (len(starttime) > 0 and len(endtime) > 0):
            timeloglist.append(time_diff(starttime, endtime))

    return add_time(timeloglist)


if __name__ == "__main__":
    app.run(debug=True)
   